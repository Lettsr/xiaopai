const toolsData = [
    {
        id: 'calculator',
        name: '科学计算器',
        description: '支持基础运算、科学计算、历史记录的专业计算器',
        icon: '🔢',
        category: 'math',
        path: 'tools/calculator/index.html'
    },
    {
        id: 'percentage-calculator',
        name: '百分比计算器',
        description: '快速计算增加/减少百分比，求百分比',
        icon: '📊',
        category: 'math',
        path: 'tools/percentage-calculator/index.html'
    },
    {
        id: 'gcd-lcm-calculator',
        name: '最大公约数/最小公倍数',
        description: '计算两个数的GCD和LCM',
        icon: '🔢',
        category: 'math',
        path: 'tools/gcd-lcm-calculator/index.html'
    },
    {
        id: 'base-converter',
        name: '进制转换器',
        description: '二进制/八进制/十进制/十六进制互相转换',
        icon: '🔄',
        category: 'math',
        path: 'tools/base-converter/index.html'
    },
    {
        id: 'bmi-calculator',
        name: 'BMI计算器',
        description: '身体质量指数计算，了解您的健康状况',
        icon: '⚖️',
        category: 'health',
        path: 'tools/bmi-calculator/index.html'
    },
    {
        id: 'bmr-calculator',
        name: '基础代谢率BMR',
        description: '计算您的基础代谢消耗',
        icon: '🔥',
        category: 'health',
        path: 'tools/bmr-calculator/index.html'
    },
    {
        id: 'currency',
        name: '货币换算',
        description: '汇率查询，支持全球主要货币互相换算',
        icon: '💱',
        category: 'unit',
        path: 'tools/currency/index.html'
    },
    {
        id: 'qrcode',
        name: '二维码生成',
        description: '快速生成自定义二维码，支持多种样式和颜色',
        icon: '📱',
        category: 'utility',
        path: 'tools/qrcode/index.html'
    },
    {
        id: 'unit-converter',
        name: '单位转换',
        description: '长度、重量、温度、面积等多种单位快速转换',
        icon: '📏',
        category: 'unit',
        path: 'tools/unit-converter/index.html'
    },
    {
        id: 'password-generator',
        name: '随机密码生成',
        description: '生成高强度随机密码，支持自定义规则',
        icon: '🔐',
        category: 'utility',
        path: 'tools/password-generator/index.html'
    },
    {
        id: 'color-picker',
        name: '颜色选择器',
        description: '取色、配色、颜色格式转换一站式工具',
        icon: '🎨',
        category: 'dev',
        path: 'tools/color-picker/index.html'
    },
    {
        id: 'json-formatter',
        name: 'JSON格式化',
        description: 'JSON数据格式化、压缩、校验与高亮显示',
        icon: '📋',
        category: 'dev',
        path: 'tools/json-formatter/index.html'
    },
    {
        id: 'base64',
        name: 'Base64编解码',
        description: '文本与Base64编码互相转换工具',
        icon: '🧬',
        category: 'text',
        path: 'tools/base64/index.html'
    },
    {
        id: 'timestamp',
        name: '时间戳转换',
        description: '时间戳与日期时间格式互相转换',
        icon: '⏰',
        category: 'time',
        path: 'tools/timestamp/index.html'
    },
    {
        id: 'date-difference',
        name: '日期差计算',
        description: '计算两个日期之间的差值',
        icon: '📅',
        category: 'time',
        path: 'tools/date-difference/index.html'
    },
    {
        id: 'age-calculator',
        name: '年龄计算器',
        description: '计算您的精确年龄',
        icon: '🎂',
        category: 'time',
        path: 'tools/age-calculator/index.html'
    },
    {
        id: 'text-counter',
        name: '文本统计',
        description: '统计字数、字符数、行数等信息',
        icon: '📊',
        category: 'text',
        path: 'tools/text-counter/index.html'
    },
    {
        id: 'url-encode',
        name: 'URL编解码',
        description: 'URL编码与解码转换工具',
        icon: '🔗',
        category: 'text',
        path: 'tools/url-encode/index.html'
    },
    {
        id: 'short-link',
        name: '短链接生成',
        description: '本地生成短链接（演示用途，不真实跳转）',
        icon: '🔗',
        category: 'utility',
        path: 'tools/short-link/index.html'
    },
    {
        id: 'uuid-generator',
        name: 'UUID生成器',
        description: '生成唯一标识符UUID v4，支持批量生成',
        icon: '🆔',
        category: 'utility',
        path: 'tools/uuid-generator/index.html'
    },
    {
        id: 'barcode',
        name: '条形码生成',
        description: '生成Code 128条形码，支持自定义尺寸',
        icon: '📊',
        category: 'utility',
        path: 'tools/barcode/index.html'
    },
    {
        id: 'string-reverse',
        name: '字符串反转',
        description: '快速反转文本内容，支持字符或单词反转',
        icon: '🔄',
        category: 'text',
        path: 'tools/string-reverse/index.html'
    },
    {
        id: 'list-dedup',
        name: '列表去重',
        description: '去除列表中的重复项，支持排序和忽略大小写',
        icon: '📋',
        category: 'text',
        path: 'tools/list-dedup/index.html'
    },
    {
        id: 'pinyin-initial',
        name: '拼音首字母提取',
        description: '提取中文字符的拼音首字母',
        icon: '🔤',
        category: 'text',
        path: 'tools/pinyin-initial/index.html'
    },
    {
        id: 'mortgage-calculator',
        name: '房贷计算器',
        description: '等额本息/等额本金双模式，支持还款明细',
        icon: '🏠',
        category: 'finance',
        path: 'tools/mortgage-calculator/index.html'
    },
    {
        id: 'car-loan-calculator',
        name: '车贷计算器',
        description: '快速计算购车贷款月供和总费用',
        icon: '🚗',
        category: 'finance',
        path: 'tools/car-loan-calculator/index.html'
    },
    {
        id: 'deposit-calculator',
        name: '存款利息计算器',
        description: '计算定期/活期存款收益',
        icon: '💰',
        category: 'finance',
        path: 'tools/deposit-calculator/index.html'
    },
    {
        id: 'bonus-tax-calculator',
        name: '年终奖个税计算器',
        description: '单独计税/合并计税双模式',
        icon: '🎁',
        category: 'finance',
        path: 'tools/bonus-tax-calculator/index.html'
    },
    {
        id: 'discount-calculator',
        name: '打折计算器',
        description: '快速计算折扣价格和节省金额',
        icon: '🎉',
        category: 'finance',
        path: 'tools/discount-calculator/index.html'
    },
    {
        id: 'tip-calculator',
        name: '小费计算器',
        description: '轻松计算应付小费和人均金额',
        icon: '💵',
        category: 'finance',
        path: 'tools/tip-calculator/index.html'
    },
    {
        id: 'mileage-calculator',
        name: '里程计算器',
        description: '计算车辆油耗与油费',
        icon: '🚗',
        category: 'finance',
        path: 'tools/mileage-calculator/index.html'
    },
    {
        id: 'electricity-calculator',
        name: '电费估算',
        description: '快速估算用电费用，支持阶梯电价',
        icon: '💡',
        category: 'finance',
        path: 'tools/electricity-calculator/index.html'
    },
    {
        id: 'phone-bill-calculator',
        name: '话费估算',
        description: '快速估算手机话费',
        icon: '📱',
        category: 'finance',
        path: 'tools/phone-bill-calculator/index.html'
    }
];

let favorites = Utils.storage.get('favorites', []);
let currentCategory = 'all';
let currentView = 'grid';

function init() {
    renderTools();
    updateDateTime();
    setInterval(updateDateTime, 1000);
    bindEvents();
    updateFavorites();
    updateTotalCount();
    updateThemeButton();
}

function updateThemeButton() {
    const icon = document.querySelector('.theme-icon');
    const text = document.querySelector('.theme-text');
    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    icon.textContent = isDark ? '🌙' : '☀️';
    text.textContent = isDark ? '深色模式' : '浅色模式';
}

function renderTools(filter = '') {
    const grid = document.getElementById('toolsGrid');
    let filteredTools = toolsData;

    if (currentCategory !== 'all') {
        filteredTools = filteredTools.filter(tool => tool.category === currentCategory);
    }

    if (filter) {
        const lowerFilter = filter.toLowerCase();
        filteredTools = filteredTools.filter(tool => 
            tool.name.toLowerCase().includes(lowerFilter) ||
            tool.description.toLowerCase().includes(lowerFilter)
        );
    }

    grid.innerHTML = filteredTools.map(tool => `
        <div class="tool-card animate-fadeIn" data-id="${tool.id}" data-path="${tool.path}">
            <span class="tool-tag">${getCategoryName(tool.category)}</span>
            <div class="tool-icon">${tool.icon}</div>
            <h3>${tool.name}</h3>
            <p>${tool.description}</p>
        </div>
    `).join('');

    grid.className = `tools-grid ${currentView === 'list' ? 'list-view' : ''}`;
}

function getCategoryName(category) {
    const names = {
        math: '数学计算',
        health: '健康计算',
        time: '时间日期',
        unit: '单位换算',
        text: '文本编码',
        dev: '开发工具',
        utility: '实用小工具',
        finance: '财务生活'
    };
    return names[category] || category;
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };
    document.getElementById('datetime').textContent = now.toLocaleString('zh-CN', options);
}

function updateTotalCount() {
    document.getElementById('totalCount').textContent = toolsData.length;
}

function bindEvents() {
    document.getElementById('searchInput').addEventListener('input', 
        Utils.debounce((e) => renderTools(e.target.value), 300)
    );

    document.querySelectorAll('.nav-item[data-category]').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            currentCategory = item.dataset.category;
            
            const titles = {
                all: '全部工具',
                math: '数学计算',
                health: '健康计算',
                time: '时间日期',
                unit: '单位换算',
                text: '文本编码',
                dev: '开发工具',
                utility: '实用小工具',
                finance: '财务生活'
            };
            document.getElementById('sectionTitle').textContent = titles[currentCategory] || '全部工具';
            renderTools(document.getElementById('searchInput').value);
        });
    });

    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentView = btn.dataset.view;
            renderTools(document.getElementById('searchInput').value);
        });
    });

    document.getElementById('toolsGrid').addEventListener('click', (e) => {
        const card = e.target.closest('.tool-card');
        if (card) {
            openTool(card.dataset.id, card.dataset.path);
        }
    });

    document.getElementById('sidebarToggle').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('collapsed');
    });

    document.getElementById('menuBtn').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('mobile-open');
    });

    document.getElementById('closeModal').addEventListener('click', closeTool);
    document.getElementById('modalOverlay').addEventListener('click', closeTool);

    document.getElementById('openBtn').addEventListener('click', () => {
        const frame = document.getElementById('toolFrame');
        if (frame.src) {
            window.open(frame.src, '_blank');
        }
    });

    document.getElementById('favoriteBtn').addEventListener('click', toggleFavorite);

    document.getElementById('themeToggle').addEventListener('click', () => {
        ThemeManager.toggle();
        const icon = document.querySelector('.theme-icon');
        const text = document.querySelector('.theme-text');
        const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
        icon.textContent = isDark ? '🌙' : '☀️';
        text.textContent = isDark ? '深色模式' : '浅色模式';
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeTool();
        }
    });
}

function openTool(id, path) {
    const tool = toolsData.find(t => t.id === id);
    if (!tool) return;

    document.getElementById('modalTitle').textContent = tool.name;
    document.getElementById('toolFrame').src = path;
    document.getElementById('toolModal').classList.add('active');
    document.getElementById('modalOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';

    const isFavorite = favorites.includes(id);
    const favBtn = document.getElementById('favoriteBtn');
    favBtn.classList.toggle('active', isFavorite);
    favBtn.querySelector('span').textContent = isFavorite ? '★' : '☆';
    favBtn.dataset.toolId = id;
}

function closeTool() {
    document.getElementById('toolModal').classList.remove('active');
    document.getElementById('modalOverlay').classList.remove('active');
    document.body.style.overflow = '';
    setTimeout(() => {
        document.getElementById('toolFrame').src = '';
    }, 300);
}

function toggleFavorite() {
    const btn = document.getElementById('favoriteBtn');
    const toolId = btn.dataset.toolId;
    
    const index = favorites.indexOf(toolId);
    if (index > -1) {
        favorites.splice(index, 1);
        btn.classList.remove('active');
        btn.querySelector('span').textContent = '☆';
        Utils.showNotification('已取消收藏', 'info');
    } else {
        favorites.push(toolId);
        btn.classList.add('active');
        btn.querySelector('span').textContent = '★';
        Utils.showNotification('已添加收藏', 'success');
    }
    
    Utils.storage.set('favorites', favorites);
    updateFavorites();
}

function updateFavorites() {
    const list = document.getElementById('favoritesList');
    
    if (favorites.length === 0) {
        list.innerHTML = '<p class="empty-favorites">暂无收藏</p>';
        return;
    }

    list.innerHTML = favorites.map(id => {
        const tool = toolsData.find(t => t.id === id);
        if (!tool) return '';
        return `
            <div class="favorite-item" data-id="${tool.id}" data-path="${tool.path}">
                <span>${tool.icon}</span>
                <span>${tool.name}</span>
            </div>
        `;
    }).join('');

    list.querySelectorAll('.favorite-item').forEach(item => {
        item.addEventListener('click', () => {
            openTool(item.dataset.id, item.dataset.path);
        });
    });
}

document.addEventListener('DOMContentLoaded', init);
