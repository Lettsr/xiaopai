class TextCounter {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('textInput').addEventListener('input', () => this.count());

        document.getElementById('clearBtn').addEventListener('click', () => {
            document.getElementById('textInput').value = '';
            this.count();
        });

        document.getElementById('copyBtn').addEventListener('click', () => {
            const text = document.getElementById('textInput').value;
            Utils.copyToClipboard(text);
            Utils.showNotification('已复制到剪贴板', 'success');
        });
    }

    count() {
        const text = document.getElementById('textInput').value;

        const charCount = text.length;
        const charNoSpace = text.replace(/\s/g, '').length;
        const spaceCount = (text.match(/\s/g) || []).length;

        const chineseCount = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
        const englishCount = (text.match(/[a-zA-Z]/g) || []).length;
        const numberCount = (text.match(/[0-9]/g) || []).length;
        const punctuationCount = (text.match(/[，。！？、；：""''（）【】《》,.!?;:'"()\[\]{}<>]/g) || []).length;
        const otherCount = charCount - chineseCount - englishCount - numberCount - punctuationCount - spaceCount;

        const words = text.trim().split(/\s+/).filter(w => w.length > 0);
        const wordCount = text.trim() === '' ? 0 : words.length;

        const lines = text.split('\n');
        const lineCount = text === '' ? 0 : lines.length;

        const sentences = text.split(/[。！？.!?]+/).filter(s => s.trim().length > 0);
        const sentenceCount = sentences.length;

        const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
        const paragraphCount = text.trim() === '' ? 0 : Math.max(1, paragraphs.length);

        document.getElementById('charCount').textContent = charCount;
        document.getElementById('charNoSpace').textContent = charNoSpace;
        document.getElementById('wordCount').textContent = wordCount;
        document.getElementById('lineCount').textContent = lineCount;
        document.getElementById('sentenceCount').textContent = sentenceCount;
        document.getElementById('paragraphCount').textContent = paragraphCount;

        document.getElementById('chineseCount').textContent = chineseCount;
        document.getElementById('englishCount').textContent = englishCount;
        document.getElementById('numberCount').textContent = numberCount;
        document.getElementById('punctuationCount').textContent = punctuationCount;
        document.getElementById('spaceCount').textContent = spaceCount;
        document.getElementById('otherCount').textContent = Math.max(0, otherCount);

        const chineseReadingSpeed = 300;
        const englishReadingSpeed = 200;
        const speechSpeed = 150;

        const chineseReadingTime = Math.ceil(chineseCount / chineseReadingSpeed);
        const englishReadingTime = Math.ceil(wordCount / englishReadingSpeed);
        const speechTime = Math.ceil(wordCount / speechSpeed);

        document.getElementById('chineseReading').textContent = `${chineseReadingTime} 分钟`;
        document.getElementById('englishReading').textContent = `${englishReadingTime} 分钟`;
        document.getElementById('speechTime').textContent = `${speechTime} 分钟`;
    }
}

document.addEventListener('DOMContentLoaded', () => new TextCounter());
