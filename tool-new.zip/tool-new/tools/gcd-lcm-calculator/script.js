function calculate() {
    const a = parseInt(document.getElementById('num1').value);
    const b = parseInt(document.getElementById('num2').value);

    if (!a || !b) {
        Utils.showNotification('请输入两个数字', 'error');
        return;
    }

    function gcd(x, y) {
        while (y !== 0) {
            const temp = y;
            y = x % y;
            x = temp;
        }
        return x;
    }

    function lcm(x, y) {
        return (x * y) / gcd(x, y);
    }

    document.getElementById('gcdResult').textContent = gcd(Math.abs(a), Math.abs(b));
    document.getElementById('lcmResult').textContent = lcm(Math.abs(a), Math.abs(b));
    document.getElementById('resultSection').style.display = 'block';
    Utils.showNotification('计算成功', 'success');
}
