class CarLoanCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const price = parseFloat(document.getElementById('carPrice').value);
        const downPercent = parseFloat(document.getElementById('downPayment').value) / 100;
        const months = parseInt(document.getElementById('loanMonths').value);
        const rate = parseFloat(document.getElementById('interestRate').value) / 100;

        if (!price || !downPercent || !months || !rate) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const totalPrice = price * 10000;
        const downPaymentAmount = totalPrice * downPercent;
        const loanAmount = totalPrice - downPaymentAmount;
        const monthlyRate = rate / 12;

        const monthlyPayment = loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months) / (Math.pow(1 + monthlyRate, months) - 1);
        const totalPayment = monthlyPayment * months;
        const totalInterest = totalPayment - loanAmount;

        document.getElementById('downPaymentAmount').textContent = `¥${downPaymentAmount.toFixed(2)}`;
        document.getElementById('loanAmount').textContent = `¥${loanAmount.toFixed(2)}`;
        document.getElementById('monthlyPayment').textContent = `¥${monthlyPayment.toFixed(2)}`;
        document.getElementById('totalInterest').textContent = `¥${totalInterest.toFixed(2)}`;
        document.getElementById('totalPayment').textContent = `¥${totalPayment.toFixed(2)}`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new CarLoanCalculator());
