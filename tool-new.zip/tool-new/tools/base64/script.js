class Base64Tool {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('encodeBtn').addEventListener('click', () => this.encode());
        document.getElementById('decodeBtn').addEventListener('click', () => this.decode());

        document.getElementById('copyEncode').addEventListener('click', () => {
            this.copyToClipboard('encodeOutput', 'copyEncode');
        });

        document.getElementById('copyDecode').addEventListener('click', () => {
            this.copyToClipboard('decodeOutput', 'copyDecode');
        });

        document.getElementById('encodeInput').addEventListener('input', 
            Utils.debounce(() => this.encode(), 300)
        );

        document.getElementById('decodeInput').addEventListener('input', 
            Utils.debounce(() => this.decode(), 300)
        );
    }

    encode() {
        const input = document.getElementById('encodeInput').value;
        if (!input) {
            document.getElementById('encodeOutput').value = '';
            return;
        }

        try {
            let encoded = btoa(unescape(encodeURIComponent(input)));
            
            if (document.getElementById('urlSafe').checked) {
                encoded = encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
            }
            
            document.getElementById('encodeOutput').value = encoded;
        } catch (e) {
            Utils.showNotification('编码失败: ' + e.message, 'error');
        }
    }

    decode() {
        const input = document.getElementById('decodeInput').value.trim();
        if (!input) {
            document.getElementById('decodeOutput').value = '';
            return;
        }

        try {
            let base64 = input;
            
            if (document.getElementById('urlSafe').checked) {
                base64 = base64.replace(/-/g, '+').replace(/_/g, '/');
                while (base64.length % 4) {
                    base64 += '=';
                }
            }
            
            const decoded = decodeURIComponent(escape(atob(base64)));
            document.getElementById('decodeOutput').value = decoded;
        } catch (e) {
            document.getElementById('decodeOutput').value = '解码失败: 无效的Base64字符串';
            Utils.showNotification('解码失败: 无效的Base64字符串', 'error');
        }
    }

    async copyToClipboard(inputId, btnId) {
        const text = document.getElementById(inputId).value;
        if (!text) return;

        const btn = document.getElementById(btnId);
        const success = await Utils.copyToClipboard(text);

        if (success) {
            btn.textContent = '已复制';
            btn.classList.add('copied');
            Utils.showNotification('已复制到剪贴板', 'success');

            setTimeout(() => {
                btn.textContent = '复制';
                btn.classList.remove('copied');
            }, 2000);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => new Base64Tool());
