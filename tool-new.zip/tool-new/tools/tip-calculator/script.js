class TipCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const billAmount = parseFloat(document.getElementById('billAmount').value);
        const tipPercent = parseFloat(document.getElementById('tipPercent').value);
        const splitCount = parseInt(document.getElementById('splitCount').value);

        if (!billAmount || !tipPercent || !splitCount) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const tipAmount = billAmount * (tipPercent / 100);
        const totalAmount = billAmount + tipAmount;
        const perPerson = totalAmount / splitCount;

        document.getElementById('tipAmount').textContent = `¥${tipAmount.toFixed(2)}`;
        document.getElementById('totalAmount').textContent = `¥${totalAmount.toFixed(2)}`;

        if (splitCount > 1) {
            document.getElementById('perPerson').textContent = `¥${perPerson.toFixed(2)}`;
            document.getElementById('perPersonItem').style.display = 'block';
        } else {
            document.getElementById('perPersonItem').style.display = 'none';
        }

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new TipCalculator());
