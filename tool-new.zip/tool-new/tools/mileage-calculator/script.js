class MileageCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const distance = parseFloat(document.getElementById('distance').value);
        const fuelConsumption = parseFloat(document.getElementById('fuelConsumption').value);
        const fuelPrice = parseFloat(document.getElementById('fuelPrice').value);

        if (!distance || !fuelConsumption || !fuelPrice) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const fuelUsed = (distance / 100) * fuelConsumption;
        const fuelCost = fuelUsed * fuelPrice;
        const costPerKm = fuelCost / distance;

        document.getElementById('fuelUsed').textContent = `${fuelUsed.toFixed(2)} L`;
        document.getElementById('fuelCost').textContent = `¥${fuelCost.toFixed(2)}`;
        document.getElementById('costPerKm').textContent = `¥${costPerKm.toFixed(2)}`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new MileageCalculator());
