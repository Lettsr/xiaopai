function convert() {
    const value = document.getElementById('inputValue').value.trim();
    const base = parseInt(document.getElementById('inputBase').value);

    if (!value) {
        document.getElementById('binary').textContent = '-';
        document.getElementById('octal').textContent = '-';
        document.getElementById('decimal').textContent = '-';
        document.getElementById('hex').textContent = '-';
        return;
    }

    try {
        const decimal = parseInt(value, base);
        
        if (isNaN(decimal)) {
            Utils.showNotification('无效的数值', 'error');
            return;
        }

        document.getElementById('binary').textContent = decimal.toString(2);
        document.getElementById('octal').textContent = decimal.toString(8);
        document.getElementById('decimal').textContent = decimal.toString(10);
        document.getElementById('hex').textContent = decimal.toString(16).toUpperCase();
    } catch (e) {
        Utils.showNotification('转换失败', 'error');
    }
}
