const sampleData = {
    object: {
        name: "张三",
        age: 28,
        email: "zhangsan@example.com",
        active: true
    },
    array: [
        { id: 1, name: "项目一", status: "完成" },
        { id: 2, name: "项目二", status: "进行中" },
        { id: 3, name: "项目三", status: "待开始" }
    ],
    nested: {
        company: "科技有限公司",
        departments: [
            {
                name: "研发部",
                employees: [
                    { name: "李四", position: "工程师" },
                    { name: "王五", position: "设计师" }
                ]
            }
        ]
    },
    api: {
        code: 200,
        message: "success",
        data: {
            total: 100,
            page: 1,
            pageSize: 10,
            list: [
                { id: 1, title: "文章一" },
                { id: 2, title: "文章二" }
            ]
        },
        timestamp: 1699876543210
    }
};

class JsonFormatter {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('formatBtn').addEventListener('click', () => this.format());
        document.getElementById('minifyBtn').addEventListener('click', () => this.minify());
        
        document.getElementById('pasteBtn').addEventListener('click', async () => {
            const text = await navigator.clipboard.readText();
            document.getElementById('jsonInput').value = text;
        });

        document.getElementById('clearBtn').addEventListener('click', () => {
            document.getElementById('jsonInput').value = '';
            document.getElementById('jsonOutput').textContent = '';
            this.updateStatus('等待输入...', '');
        });

        document.getElementById('copyBtn').addEventListener('click', () => {
            const output = document.getElementById('jsonOutput').textContent;
            Utils.copyToClipboard(output);
            Utils.showNotification('已复制到剪贴板', 'success');
        });

        document.querySelectorAll('.sample-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const sample = sampleData[btn.dataset.sample];
                document.getElementById('jsonInput').value = JSON.stringify(sample, null, 2);
                this.format();
            });
        });

        document.getElementById('jsonInput').addEventListener('input', 
            Utils.debounce(() => this.validate(), 500)
        );
    }

    format() {
        const input = document.getElementById('jsonInput').value.trim();
        if (!input) {
            this.updateStatus('请输入JSON数据', 'error');
            return;
        }

        try {
            let parsed = JSON.parse(input);
            
            if (document.getElementById('sortKeys').checked) {
                parsed = this.sortObject(parsed);
            }

            const indent = document.getElementById('indentSize').value;
            const indentStr = indent === 'tab' ? '\t' : parseInt(indent);
            const formatted = JSON.stringify(parsed, null, indentStr);
            
            this.renderOutput(formatted);
            this.updateStatus(`格式化成功 - ${this.getSize(formatted)}`, 'success');
        } catch (e) {
            this.updateStatus(`JSON格式错误: ${e.message}`, 'error');
            document.getElementById('jsonOutput').textContent = '';
        }
    }

    minify() {
        const input = document.getElementById('jsonInput').value.trim();
        if (!input) {
            this.updateStatus('请输入JSON数据', 'error');
            return;
        }

        try {
            const parsed = JSON.parse(input);
            const minified = JSON.stringify(parsed);
            
            document.getElementById('jsonOutput').textContent = minified;
            this.updateStatus(`压缩成功 - ${this.getSize(minified)}`, 'success');
        } catch (e) {
            this.updateStatus(`JSON格式错误: ${e.message}`, 'error');
        }
    }

    validate() {
        const input = document.getElementById('jsonInput').value.trim();
        if (!input) {
            this.updateStatus('等待输入...', '');
            return;
        }

        try {
            JSON.parse(input);
            this.updateStatus('JSON格式有效 ✓', 'success');
        } catch (e) {
            this.updateStatus(`格式错误: ${e.message}`, 'error');
        }
    }

    renderOutput(json) {
        const output = document.getElementById('jsonOutput');
        output.innerHTML = this.syntaxHighlight(json);
    }

    syntaxHighlight(json) {
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, (match) => {
            let cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    }

    sortObject(obj) {
        if (typeof obj !== 'object' || obj === null) {
            return obj;
        }

        if (Array.isArray(obj)) {
            return obj.map(item => this.sortObject(item));
        }

        const sorted = {};
        Object.keys(obj).sort().forEach(key => {
            sorted[key] = this.sortObject(obj[key]);
        });
        return sorted;
    }

    getSize(str) {
        const bytes = new Blob([str]).size;
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
        return (bytes / 1024 / 1024).toFixed(2) + ' MB';
    }

    updateStatus(message, type) {
        const statusText = document.querySelector('.status-text');
        statusText.textContent = message;
        statusText.className = 'status-text ' + type;
    }
}

document.addEventListener('DOMContentLoaded', () => new JsonFormatter());
