class MortgageCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const amount = parseFloat(document.getElementById('loanAmount').value);
        const years = parseInt(document.getElementById('loanYears').value);
        const rate = parseFloat(document.getElementById('interestRate').value) / 100;
        const method = document.querySelector('input[name="method"]:checked').value;

        if (!amount || !years || !rate) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const principal = amount * 10000;
        const months = years * 12;
        const monthlyRate = rate / 12;

        let result;
        if (method === 'equal') {
            result = this.calculateEqualPayment(principal, months, monthlyRate);
        } else {
            result = this.calculateEqualPrincipal(principal, months, monthlyRate);
        }

        this.displayResult(result);
    }

    calculateEqualPayment(principal, months, monthlyRate) {
        const monthlyPayment = principal * monthlyRate * Math.pow(1 + monthlyRate, months) / (Math.pow(1 + monthlyRate, months) - 1);
        const totalPayment = monthlyPayment * months;
        const totalInterest = totalPayment - principal;

        const schedule = [];
        let remaining = principal;
        for (let i = 1; i <= Math.min(months, 24); i++) {
            const interest = remaining * monthlyRate;
            const principalPart = monthlyPayment - interest;
            remaining -= principalPart;
            schedule.push({
                month: i,
                payment: monthlyPayment,
                principal: principalPart,
                interest: interest,
                remaining: remaining
            });
        }

        return {
            monthlyPayment,
            totalInterest,
            totalPayment,
            schedule
        };
    }

    calculateEqualPrincipal(principal, months, monthlyRate) {
        const monthlyPrincipal = principal / months;
        let totalInterest = 0;
        const schedule = [];
        let remaining = principal;

        for (let i = 1; i <= months; i++) {
            const interest = remaining * monthlyRate;
            const payment = monthlyPrincipal + interest;
            totalInterest += interest;
            remaining -= monthlyPrincipal;

            if (i <= 24) {
                schedule.push({
                    month: i,
                    payment: payment,
                    principal: monthlyPrincipal,
                    interest: interest,
                    remaining: remaining
                });
            }
        }

        const totalPayment = principal + totalInterest;
        const firstMonthPayment = principal / months + principal * monthlyRate;

        return {
            monthlyPayment: firstMonthPayment,
            totalInterest,
            totalPayment,
            schedule,
            isPrincipal: true
        };
    }

    displayResult(result) {
        if (result.isPrincipal) {
            document.getElementById('monthlyPayment').innerHTML = `首月 ¥${result.monthlyPayment.toFixed(2)}<br><small class="note">逐月递减</small>`;
        } else {
            document.getElementById('monthlyPayment').textContent = `¥${result.monthlyPayment.toFixed(2)}`;
        }
        document.getElementById('totalInterest').textContent = `¥${result.totalInterest.toFixed(2)}`;
        document.getElementById('totalPayment').textContent = `¥${result.totalPayment.toFixed(2)}`;

        const tbody = document.getElementById('scheduleBody');
        tbody.innerHTML = '';
        result.schedule.forEach(item => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${item.month}</td>
                <td>¥${item.payment.toFixed(2)}</td>
                <td>¥${item.principal.toFixed(2)}</td>
                <td>¥${item.interest.toFixed(2)}</td>
                <td>¥${item.remaining.toFixed(2)}</td>
            `;
            tbody.appendChild(tr);
        });

        document.getElementById('resultSection').style.display = 'block';
        document.getElementById('scheduleSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new MortgageCalculator());
