class BonusTaxCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const bonus = parseFloat(document.getElementById('bonusAmount').value);
        const salary = parseFloat(document.getElementById('monthlySalary').value) || 0;
        const deduction = parseFloat(document.getElementById('specialDeduction').value) || 0;
        const method = document.querySelector('input[name="method"]:checked').value;

        if (!bonus) {
            Utils.showNotification('请输入年终奖金额', 'error');
            return;
        }

        let tax, afterTax, rate;
        if (method === 'separate') {
            const result = this.calculateSeparate(bonus);
            tax = result.tax;
            rate = result.rate;
        } else {
            const result = this.calculateCombined(bonus, salary, deduction);
            tax = result.tax;
            rate = result.rate;
        }

        afterTax = bonus - tax;

        document.getElementById('taxAmount').textContent = `¥${tax.toFixed(2)}`;
        document.getElementById('afterTax').textContent = `¥${afterTax.toFixed(2)}`;
        document.getElementById('taxRate').textContent = `${(rate * 100).toFixed(0)}%`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }

    calculateSeparate(bonus) {
        const monthly = bonus / 12;
        const brackets = [
            { limit: 3000, rate: 0.03, quick: 0 },
            { limit: 12000, rate: 0.1, quick: 210 },
            { limit: 25000, rate: 0.2, quick: 1410 },
            { limit: 35000, rate: 0.25, quick: 2660 },
            { limit: 55000, rate: 0.3, quick: 4410 },
            { limit: 80000, rate: 0.35, quick: 7160 },
            { limit: Infinity, rate: 0.45, quick: 15160 }
        ];

        for (const bracket of brackets) {
            if (monthly <= bracket.limit) {
                return {
                    tax: bonus * bracket.rate - bracket.quick,
                    rate: bracket.rate
                };
            }
        }
    }

    calculateCombined(bonus, salary, deduction) {
        const taxable = Math.max(0, salary + bonus - 5000 - deduction);
        const brackets = [
            { limit: 3000, rate: 0.03, quick: 0 },
            { limit: 12000, rate: 0.1, quick: 210 },
            { limit: 25000, rate: 0.2, quick: 1410 },
            { limit: 35000, rate: 0.25, quick: 2660 },
            { limit: 55000, rate: 0.3, quick: 4410 },
            { limit: 80000, rate: 0.35, quick: 7160 },
            { limit: Infinity, rate: 0.45, quick: 15160 }
        ];

        for (const bracket of brackets) {
            if (taxable <= bracket.limit) {
                return {
                    tax: taxable * bracket.rate - bracket.quick,
                    rate: bracket.rate
                };
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', () => new BonusTaxCalculator());
