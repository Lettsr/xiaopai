class TimestampConverter {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateCurrentTime();
        setInterval(() => this.updateCurrentTime(), 1000);
        this.renderQuickTimestamps();
        this.setDefaultDate();
    }

    bindEvents() {
        document.getElementById('toDateBtn').addEventListener('click', () => this.toDate());
        document.getElementById('toTimestampBtn').addEventListener('click', () => this.toTimestamp());

        document.getElementById('timestampInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.toDate();
        });

        document.getElementById('dateInput').addEventListener('change', () => this.toTimestamp());

        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.dataset.target;
                const text = document.getElementById(targetId).textContent;
                Utils.copyToClipboard(text);
                Utils.showNotification('已复制', 'success');
            });
        });
    }

    updateCurrentTime() {
        const now = Date.now();
        document.getElementById('currentTimestamp').textContent = Math.floor(now / 1000);
        document.getElementById('currentDate').textContent = Utils.formatDate(now);
    }

    setDefaultDate() {
        const now = new Date();
        const offset = now.getTimezoneOffset() * 60000;
        const local = new Date(now - offset);
        document.getElementById('dateInput').value = local.toISOString().slice(0, 16);
        this.toTimestamp();
    }

    toDate() {
        const input = document.getElementById('timestampInput').value.trim();
        if (!input) return;

        let timestamp = parseInt(input);
        
        if (isNaN(timestamp)) {
            Utils.showNotification('请输入有效的时间戳', 'error');
            return;
        }

        if (timestamp.toString().length <= 10) {
            timestamp *= 1000;
        }

        const date = new Date(timestamp);

        if (isNaN(date.getTime())) {
            Utils.showNotification('无效的时间戳', 'error');
            return;
        }

        document.getElementById('localDate').textContent = Utils.formatDate(date);
        document.getElementById('utcDate').textContent = date.toUTCString();
        document.getElementById('isoDate').textContent = date.toISOString();
    }

    toTimestamp() {
        const input = document.getElementById('dateInput').value;
        if (!input) return;

        const date = new Date(input);
        const milli = date.getTime();
        const second = Math.floor(milli / 1000);

        document.getElementById('secondTimestamp').textContent = second;
        document.getElementById('milliTimestamp').textContent = milli;
    }

    renderQuickTimestamps() {
        const now = Date.now();
        const second = Math.floor(now / 1000);
        
        const quickItems = [
            { label: '今天开始', time: new Date(new Date().setHours(0, 0, 0, 0)) },
            { label: '今天结束', time: new Date(new Date().setHours(23, 59, 59, 999)) },
            { label: '本周开始', time: this.getWeekStart() },
            { label: '本月开始', time: new Date(new Date().getFullYear(), new Date().getMonth(), 1) }
        ];

        const grid = document.getElementById('quickGrid');
        grid.innerHTML = quickItems.map(item => `
            <div class="quick-item" data-timestamp="${Math.floor(item.time.getTime() / 1000)}">
                <span class="label">${item.label}</span>
                <span class="value">${Math.floor(item.time.getTime() / 1000)}</span>
            </div>
        `).join('');

        grid.querySelectorAll('.quick-item').forEach(item => {
            item.addEventListener('click', () => {
                document.getElementById('timestampInput').value = item.dataset.timestamp;
                this.toDate();
            });
        });
    }

    getWeekStart() {
        const now = new Date();
        const day = now.getDay() || 7;
        return new Date(now.getFullYear(), now.getMonth(), now.getDate() - day + 1);
    }
}

document.addEventListener('DOMContentLoaded', () => new TimestampConverter());
