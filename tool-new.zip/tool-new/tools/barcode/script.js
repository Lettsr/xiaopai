class BarcodeGenerator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('generateBtn').addEventListener('click', () => this.generate());
        document.getElementById('barcodeInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.generate();
        });
        document.getElementById('downloadBtn').addEventListener('click', () => this.download());
        document.getElementById('copyBtn').addEventListener('click', () => this.copy());
    }

    generate() {
        const text = document.getElementById('barcodeInput').value.trim();
        
        if (!text) {
            Utils.showNotification('请输入内容', 'error');
            return;
        }

        const width = parseInt(document.getElementById('barcodeWidth').value);
        const height = parseInt(document.getElementById('barcodeHeight').value);
        const canvas = document.getElementById('barcodeCanvas');

        try {
            Code128.draw(canvas, text, { width, height });
            document.getElementById('resultSection').style.display = 'block';
            Utils.showNotification('条形码生成成功', 'success');
        } catch (e) {
            console.error(e);
            Utils.showNotification('生成失败', 'error');
        }
    }

    download() {
        const canvas = document.getElementById('barcodeCanvas');
        const link = document.createElement('a');
        link.download = 'barcode.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
        Utils.showNotification('下载成功', 'success');
    }

    copy() {
        const canvas = document.getElementById('barcodeCanvas');
        canvas.toBlob((blob) => {
            const item = new ClipboardItem({ 'image/png': blob });
            navigator.clipboard.write([item]).then(() => {
                Utils.showNotification('已复制到剪贴板', 'success');
            }).catch(() => {
                Utils.showNotification('复制失败', 'error');
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => new BarcodeGenerator());
