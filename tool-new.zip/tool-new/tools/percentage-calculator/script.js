function calculate(type) {
    let result;
    
    if (type === 'increase') {
        const original = parseFloat(document.getElementById('incOriginal').value);
        const percent = parseFloat(document.getElementById('incPercent').value);
        result = original * (1 + percent / 100);
    } else if (type === 'decrease') {
        const original = parseFloat(document.getElementById('decOriginal').value);
        const percent = parseFloat(document.getElementById('decPercent').value);
        result = original * (1 - percent / 100);
    } else {
        const part = parseFloat(document.getElementById('findPart').value);
        const total = parseFloat(document.getElementById('findTotal').value);
        result = (part / total) * 100;
    }

    document.getElementById('resultValue').textContent = 
        type === 'find' ? `${result.toFixed(2)}%` : `¥${result.toFixed(2)}`;
    document.getElementById('resultSection').style.display = 'block';
    Utils.showNotification('计算成功', 'success');
}

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');
        document.getElementById('resultSection').style.display = 'none';
    });
});
