class ColorPicker {
    constructor() {
        this.currentColor = { r: 99, g: 102, b: 241 };
        this.history = Utils.storage.get('color_history', []);
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateColor();
        this.renderHistory();
        this.generatePalette();
    }

    bindEvents() {
        document.getElementById('colorPicker').addEventListener('input', (e) => {
            this.setHexColor(e.target.value);
        });

        document.getElementById('hexInput').addEventListener('input', (e) => {
            const hex = e.target.value;
            if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
                this.setHexColor(hex);
            }
        });

        document.getElementById('rgbInput').addEventListener('input', (e) => {
            const match = e.target.value.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/);
            if (match) {
                this.setRgbColor(parseInt(match[1]), parseInt(match[2]), parseInt(match[3]));
            }
        });

        ['redSlider', 'greenSlider', 'blueSlider'].forEach((id, index) => {
            document.getElementById(id).addEventListener('input', (e) => {
                const colors = ['r', 'g', 'b'];
                this.currentColor[colors[index]] = parseInt(e.target.value);
                this.updateColor();
            });
        });

        document.querySelectorAll('.copy-section .copy-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.copyColor(btn.dataset.format);
            });
        });

        document.getElementById('clearHistory').addEventListener('click', () => {
            this.history = [];
            Utils.storage.set('color_history', []);
            this.renderHistory();
        });
    }

    setHexColor(hex) {
        const rgb = this.hexToRgb(hex);
        this.currentColor = rgb;
        this.updateColor();
    }

    setRgbColor(r, g, b) {
        this.currentColor = { r, g, b };
        this.updateColor();
    }

    updateColor() {
        const { r, g, b } = this.currentColor;
        const hex = this.rgbToHex(r, g, b);
        const hsl = this.rgbToHsl(r, g, b);

        document.getElementById('colorPreview').style.backgroundColor = hex;
        document.getElementById('colorPicker').value = hex;
        
        document.getElementById('hexInput').value = hex;
        document.getElementById('rgbInput').value = `rgb(${r}, ${g}, ${b})`;
        document.getElementById('hslInput').value = `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`;

        document.getElementById('redSlider').value = r;
        document.getElementById('greenSlider').value = g;
        document.getElementById('blueSlider').value = b;

        document.getElementById('redValue').textContent = r;
        document.getElementById('greenValue').textContent = g;
        document.getElementById('blueValue').textContent = b;

        this.addToHistory(hex);
    }

    rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
    }

    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    rgbToHsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        const max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;

        if (max === min) {
            h = s = 0;
        } else {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
                case g: h = ((b - r) / d + 2) / 6; break;
                case b: h = ((r - g) / d + 4) / 6; break;
            }
        }

        return {
            h: Math.round(h * 360),
            s: Math.round(s * 100),
            l: Math.round(l * 100)
        };
    }

    copyColor(format) {
        let value;
        switch (format) {
            case 'hex':
                value = document.getElementById('hexInput').value;
                break;
            case 'rgb':
                value = document.getElementById('rgbInput').value;
                break;
            case 'hsl':
                value = document.getElementById('hslInput').value;
                break;
        }
        Utils.copyToClipboard(value);
        Utils.showNotification(`已复制: ${value}`, 'success');
    }

    addToHistory(hex) {
        if (this.history[0] === hex) return;
        
        this.history = this.history.filter(c => c !== hex);
        this.history.unshift(hex);
        
        if (this.history.length > 20) {
            this.history.pop();
        }
        
        Utils.storage.set('color_history', this.history);
        this.renderHistory();
    }

    renderHistory() {
        const grid = document.getElementById('historyGrid');
        
        if (this.history.length === 0) {
            grid.innerHTML = '<span class="text-muted">暂无历史</span>';
            return;
        }

        grid.innerHTML = this.history.map(hex => `
            <div class="history-item" style="background-color: ${hex}" data-color="${hex}" title="${hex}"></div>
        `).join('');

        grid.querySelectorAll('.history-item').forEach(item => {
            item.addEventListener('click', () => {
                this.setHexColor(item.dataset.color);
            });
        });
    }

    generatePalette() {
        const baseColors = [
            '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16',
            '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9',
            '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef',
            '#ec4899', '#f43f5e'
        ];

        const grid = document.getElementById('paletteGrid');
        grid.innerHTML = baseColors.map(hex => `
            <div class="palette-item" style="background-color: ${hex}" data-color="${hex}" title="${hex}"></div>
        `).join('');

        grid.querySelectorAll('.palette-item').forEach(item => {
            item.addEventListener('click', () => {
                this.setHexColor(item.dataset.color);
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => new ColorPicker());
