function calculate() {
    const startDate = new Date(document.getElementById('startDate').value);
    const endDate = new Date(document.getElementById('endDate').value);

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        Utils.showNotification('请选择两个日期', 'error');
        return;
    }

    const diff = Math.abs(endDate - startDate);
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    document.getElementById('days').textContent = days;
    document.getElementById('hours').textContent = Math.floor(diff / (1000 * 60 * 60));
    document.getElementById('minutes').textContent = Math.floor(diff / (1000 * 60));
    document.getElementById('seconds').textContent = seconds;
    document.getElementById('resultSection').style.display = 'block';
    Utils.showNotification('计算成功', 'success');
}

document.getElementById('startDate').valueAsDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
document.getElementById('endDate').valueAsDate = new Date();
