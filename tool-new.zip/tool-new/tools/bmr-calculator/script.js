function calculate() {
    const gender = document.getElementById('gender').value;
    const age = parseFloat(document.getElementById('age').value);
    const height = parseFloat(document.getElementById('height').value);
    const weight = parseFloat(document.getElementById('weight').value);

    if (!age || !height || !weight) {
        Utils.showNotification('请填写完整信息', 'error');
        return;
    }

    let bmr;
    if (gender === 'male') {
        bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
        bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }

    document.getElementById('bmrResult').textContent = Math.round(bmr);
    document.getElementById('resultSection').style.display = 'block';
    Utils.showNotification('计算成功', 'success');
}
