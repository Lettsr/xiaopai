class DepositCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateRateHint();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
        document.getElementById('depositType').addEventListener('change', () => this.updateRateHint());
    }

    updateRateHint() {
        const type = document.getElementById('depositType').value;
        const termSelect = document.getElementById('depositTerm');
        if (type === 'current') {
            termSelect.disabled = true;
            document.getElementById('interestRate').value = '0.25';
        } else {
            termSelect.disabled = false;
        }
    }

    calculate() {
        const type = document.getElementById('depositType').value;
        const amount = parseFloat(document.getElementById('depositAmount').value);
        const months = parseInt(document.getElementById('depositTerm').value);
        const rate = parseFloat(document.getElementById('interestRate').value) / 100;

        if (!amount || !rate) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        let interest;
        if (type === 'current') {
            interest = amount * rate * (months / 12);
        } else {
            interest = amount * rate * (months / 12);
        }

        const total = amount + interest;

        document.getElementById('principal').textContent = `¥${amount.toFixed(2)}`;
        document.getElementById('interest').textContent = `¥${interest.toFixed(2)}`;
        document.getElementById('total').textContent = `¥${total.toFixed(2)}`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new DepositCalculator());
