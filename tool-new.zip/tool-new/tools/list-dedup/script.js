class ListDedup {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('dedupBtn').addEventListener('click', () => this.dedup());
        document.getElementById('copyBtn').addEventListener('click', () => this.copy());
    }

    dedup() {
        const input = document.getElementById('inputList').value;
        
        if (!input.trim()) {
            Utils.showNotification('请输入列表', 'error');
            return;
        }

        const ignoreCase = document.getElementById('ignoreCase').checked;
        const trimSpaces = document.getElementById('trimSpaces').checked;
        const sortResult = document.getElementById('sortResult').checked;

        let lines = input.split('\n');
        const countBefore = lines.length;

        const seen = new Set();
        const result = [];

        lines.forEach(line => {
            let processed = line;
            if (trimSpaces) {
                processed = processed.trim();
            }

            let key = processed;
            if (ignoreCase) {
                key = key.toLowerCase();
            }

            if (!seen.has(key)) {
                seen.add(key);
                result.push(processed);
            }
        });

        if (sortResult) {
            result.sort((a, b) => a.localeCompare(b));
        }

        document.getElementById('outputList').value = result.join('\n');
        document.getElementById('countBefore').textContent = countBefore;
        document.getElementById('countAfter').textContent = result.length;
        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification(`去重完成，移除 ${countBefore - result.length} 个重复项`, 'success');
    }

    copy() {
        const text = document.getElementById('outputList').value;
        Utils.copyToClipboard(text);
        Utils.showNotification('已复制到剪贴板', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new ListDedup());
