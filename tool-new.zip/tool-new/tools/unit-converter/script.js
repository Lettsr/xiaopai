const unitData = {
    length: {
        name: '长度',
        units: {
            m: { name: '米', ratio: 1 },
            km: { name: '千米', ratio: 1000 },
            cm: { name: '厘米', ratio: 0.01 },
            mm: { name: '毫米', ratio: 0.001 },
            mi: { name: '英里', ratio: 1609.344 },
            yd: { name: '码', ratio: 0.9144 },
            ft: { name: '英尺', ratio: 0.3048 },
            in: { name: '英寸', ratio: 0.0254 },
            nmi: { name: '海里', ratio: 1852 },
            li: { name: '里', ratio: 500 },
            zhang: { name: '丈', ratio: 3.333 },
            chi: { name: '尺', ratio: 0.333 }
        },
        quick: ['km-m', 'm-cm', 'mi-km', 'ft-m', 'in-cm']
    },
    weight: {
        name: '重量',
        units: {
            kg: { name: '千克', ratio: 1 },
            g: { name: '克', ratio: 0.001 },
            mg: { name: '毫克', ratio: 0.000001 },
            t: { name: '吨', ratio: 1000 },
            lb: { name: '磅', ratio: 0.453592 },
            oz: { name: '盎司', ratio: 0.0283495 },
            jin: { name: '斤', ratio: 0.5 },
            liang: { name: '两', ratio: 0.05 },
            qian: { name: '钱', ratio: 0.005 }
        },
        quick: ['kg-g', 't-kg', 'lb-kg', 'jin-kg', 'oz-g']
    },
    area: {
        name: '面积',
        units: {
            m2: { name: '平方米', ratio: 1 },
            km2: { name: '平方千米', ratio: 1000000 },
            cm2: { name: '平方厘米', ratio: 0.0001 },
            ha: { name: '公顷', ratio: 10000 },
            acre: { name: '英亩', ratio: 4046.86 },
            ft2: { name: '平方英尺', ratio: 0.092903 },
            mu: { name: '亩', ratio: 666.667 }
        },
        quick: ['km2-m2', 'ha-m2', 'acre-m2', 'mu-m2', 'ft2-m2']
    },
    volume: {
        name: '体积',
        units: {
            l: { name: '升', ratio: 1 },
            ml: { name: '毫升', ratio: 0.001 },
            m3: { name: '立方米', ratio: 1000 },
            cm3: { name: '立方厘米', ratio: 0.001 },
            gal: { name: '加仑(美)', ratio: 3.78541 },
            qt: { name: '夸脱', ratio: 0.946353 },
            pt: { name: '品脱', ratio: 0.473176 }
        },
        quick: ['l-ml', 'm3-l', 'gal-l', 'ml-cm3', 'qt-l']
    },
    temperature: {
        name: '温度',
        units: {
            c: { name: '摄氏度', ratio: 1 },
            f: { name: '华氏度', ratio: 1 },
            k: { name: '开尔文', ratio: 1 }
        },
        quick: ['c-f', 'c-k', 'f-k'],
        special: true
    },
    speed: {
        name: '速度',
        units: {
            mps: { name: '米/秒', ratio: 1 },
            kmh: { name: '千米/时', ratio: 0.277778 },
            mph: { name: '英里/时', ratio: 0.44704 },
            kn: { name: '节', ratio: 0.514444 },
            mach: { name: '马赫', ratio: 340.29 }
        },
        quick: ['kmh-mps', 'mph-kmh', 'kn-kmh', 'mach-mps']
    },
    data: {
        name: '数据',
        units: {
            b: { name: '字节(B)', ratio: 1 },
            kb: { name: '千字节(KB)', ratio: 1024 },
            mb: { name: '兆字节(MB)', ratio: 1048576 },
            gb: { name: '吉字节(GB)', ratio: 1073741824 },
            tb: { name: '太字节(TB)', ratio: 1099511627776 },
            pb: { name: '拍字节(PB)', ratio: 1125899906842624 }
        },
        quick: ['mb-kb', 'gb-mb', 'tb-gb', 'mb-b', 'gb-kb']
    },
    time: {
        name: '时间',
        units: {
            s: { name: '秒', ratio: 1 },
            ms: { name: '毫秒', ratio: 0.001 },
            min: { name: '分钟', ratio: 60 },
            h: { name: '小时', ratio: 3600 },
            d: { name: '天', ratio: 86400 },
            w: { name: '周', ratio: 604800 },
            mo: { name: '月', ratio: 2592000 },
            y: { name: '年', ratio: 31536000 }
        },
        quick: ['h-min', 'd-h', 'min-s', 'w-d', 'y-d']
    }
};

class UnitConverter {
    constructor() {
        this.currentCategory = 'length';
        this.fromUnit = 'm';
        this.toUnit = 'km';
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadCategory('length');
    }

    bindEvents() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.loadCategory(btn.dataset.category);
            });
        });

        document.getElementById('fromValue').addEventListener('input', () => this.convert());
        
        document.getElementById('fromUnit').addEventListener('change', (e) => {
            this.fromUnit = e.target.value;
            this.convert();
        });

        document.getElementById('toUnit').addEventListener('change', (e) => {
            this.toUnit = e.target.value;
            this.convert();
        });

        document.getElementById('swapBtn').addEventListener('click', () => this.swap());
    }

    loadCategory(category) {
        this.currentCategory = category;
        const data = unitData[category];
        const units = data.units;

        const fromSelect = document.getElementById('fromUnit');
        const toSelect = document.getElementById('toUnit');

        const options = Object.entries(units).map(([code, unit]) => 
            `<option value="${code}">${unit.name}</option>`
        ).join('');

        fromSelect.innerHTML = options;
        toSelect.innerHTML = options;

        const unitCodes = Object.keys(units);
        this.fromUnit = unitCodes[0];
        this.toUnit = unitCodes[1] || unitCodes[0];

        fromSelect.value = this.fromUnit;
        toSelect.value = this.toUnit;

        this.convert();
        this.renderQuickConvert();
    }

    convert() {
        const value = parseFloat(document.getElementById('fromValue').value) || 0;
        const data = unitData[this.currentCategory];
        
        let result;
        if (data.special && this.currentCategory === 'temperature') {
            result = this.convertTemperature(value, this.fromUnit, this.toUnit);
        } else {
            const fromRatio = data.units[this.fromUnit].ratio;
            const toRatio = data.units[this.toUnit].ratio;
            result = (value * fromRatio) / toRatio;
        }

        document.getElementById('toValue').value = this.formatNumber(result);
        
        this.updateFormula(value, result);
        this.renderAllResults(value);
    }

    convertTemperature(value, from, to) {
        let celsius;
        switch (from) {
            case 'c': celsius = value; break;
            case 'f': celsius = (value - 32) * 5 / 9; break;
            case 'k': celsius = value - 273.15; break;
        }

        switch (to) {
            case 'c': return celsius;
            case 'f': return celsius * 9 / 5 + 32;
            case 'k': return celsius + 273.15;
        }
    }

    formatNumber(num) {
        if (Math.abs(num) < 0.000001 || Math.abs(num) > 999999999) {
            return num.toExponential(6);
        }
        return parseFloat(num.toPrecision(10)).toString();
    }

    updateFormula(fromVal, toVal) {
        const data = unitData[this.currentCategory];
        const fromName = data.units[this.fromUnit].name;
        const toName = data.units[this.toUnit].name;

        document.getElementById('formulaDisplay').innerHTML = `
            <span class="formula-text">
                <span class="highlight">${fromVal}</span> ${fromName} = 
                <span class="highlight">${this.formatNumber(toVal)}</span> ${toName}
            </span>
        `;
    }

    swap() {
        const temp = this.fromUnit;
        this.fromUnit = this.toUnit;
        this.toUnit = temp;

        document.getElementById('fromUnit').value = this.fromUnit;
        document.getElementById('toUnit').value = this.toUnit;

        const fromValue = document.getElementById('fromValue').value;
        const toValue = document.getElementById('toValue').value;
        document.getElementById('fromValue').value = toValue;

        this.convert();
    }

    renderQuickConvert() {
        const data = unitData[this.currentCategory];
        const quickList = document.getElementById('quickList');

        if (!data.quick || data.quick.length === 0) {
            quickList.innerHTML = '<span class="text-muted">暂无快捷换算</span>';
            return;
        }

        quickList.innerHTML = data.quick.map(pair => {
            const [from, to] = pair.split('-');
            const fromName = data.units[from]?.name || from;
            const toName = data.units[to]?.name || to;
            return `
                <div class="quick-item" data-from="${from}" data-to="${to}">
                    ${fromName} → ${toName}
                </div>
            `;
        }).join('');

        quickList.querySelectorAll('.quick-item').forEach(item => {
            item.addEventListener('click', () => {
                this.fromUnit = item.dataset.from;
                this.toUnit = item.dataset.to;
                document.getElementById('fromUnit').value = this.fromUnit;
                document.getElementById('toUnit').value = this.toUnit;
                this.convert();
            });
        });
    }

    renderAllResults(value) {
        const data = unitData[this.currentCategory];
        const grid = document.getElementById('resultsGrid');

        const results = Object.entries(data.units).map(([code, unit]) => {
            let result;
            if (data.special && this.currentCategory === 'temperature') {
                result = this.convertTemperature(value, this.fromUnit, code);
            } else {
                const fromRatio = data.units[this.fromUnit].ratio;
                result = (value * fromRatio) / unit.ratio;
            }
            return { code, name: unit.name, value: this.formatNumber(result) };
        });

        grid.innerHTML = results.map(r => `
            <div class="result-item">
                <span class="unit-name">${r.name}</span>
                <span class="unit-value">${r.value}</span>
            </div>
        `).join('');
    }
}

document.addEventListener('DOMContentLoaded', () => new UnitConverter());
