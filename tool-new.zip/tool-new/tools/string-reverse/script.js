class StringReverse {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('reverseBtn').addEventListener('click', () => this.reverse());
        document.getElementById('copyBtn').addEventListener('click', () => this.copy());
        document.getElementById('inputText').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') this.reverse();
        });
    }

    reverse() {
        const text = document.getElementById('inputText').value;
        
        if (!text) {
            Utils.showNotification('请输入文本', 'error');
            return;
        }

        const reverseWords = document.getElementById('reverseWords').checked;
        let result;

        if (reverseWords) {
            result = text.split('\n').map(line => {
                return line.split(/(\s+)/).reverse().join('');
            }).join('\n');
        } else {
            result = text.split('').reverse().join('');
        }

        document.getElementById('outputText').value = result;
        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('反转成功', 'success');
    }

    copy() {
        const text = document.getElementById('outputText').value;
        Utils.copyToClipboard(text);
        Utils.showNotification('已复制到剪贴板', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new StringReverse());
