function calculate() {
    const birthDate = new Date(document.getElementById('birthDate').value);
    const today = new Date();

    if (isNaN(birthDate.getTime())) {
        Utils.showNotification('请选择出生日期', 'error');
        return;
    }

    if (birthDate > today) {
        Utils.showNotification('出生日期不能大于今天', 'error');
        return;
    }

    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    if (days < 0) {
        months--;
        const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        days += lastMonth.getDate();
    }

    if (months < 0) {
        years--;
        months += 12;
    }

    const diffTime = Math.abs(today - birthDate);
    const totalDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    document.getElementById('years').textContent = years;
    document.getElementById('months').textContent = months;
    document.getElementById('days').textContent = days;
    document.getElementById('totalDays').textContent = totalDays;
    document.getElementById('resultSection').style.display = 'block';
    Utils.showNotification('计算成功', 'success');
}

document.getElementById('birthDate').valueAsDate = new Date('1990-01-01');
