class DiscountCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const originalPrice = parseFloat(document.getElementById('originalPrice').value);
        const discount = parseFloat(document.getElementById('discount').value);

        if (!originalPrice || !discount) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const discountPrice = originalPrice * (discount / 10);
        const savedAmount = originalPrice - discountPrice;

        document.getElementById('discountPrice').textContent = `¥${discountPrice.toFixed(2)}`;
        document.getElementById('savedAmount').textContent = `¥${savedAmount.toFixed(2)}`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new DiscountCalculator());
