class QRCodeGenerator {
    constructor() {
        this.generatedCanvas = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateColorValues();
    }

    bindEvents() {
        document.getElementById('generateBtn').addEventListener('click', () => {
            this.generate();
        });

        document.querySelectorAll('#qrSize, #qrLevel').forEach(el => {
            el.addEventListener('change', () => this.generate());
        });

        document.getElementById('qrDarkColor').addEventListener('input', (e) => {
            document.getElementById('darkColorValue').textContent = e.target.value;
        });

        document.getElementById('qrLightColor').addEventListener('input', (e) => {
            document.getElementById('lightColorValue').textContent = e.target.value;
        });

        document.getElementById('downloadPng').addEventListener('click', () => this.downloadPng());
    }

    updateColorValues() {
        document.getElementById('darkColorValue').textContent = document.getElementById('qrDarkColor').value;
        document.getElementById('lightColorValue').textContent = document.getElementById('qrLightColor').value;
    }

    generate() {
        const content = document.getElementById('qrContent').value.trim();
        
        if (!content) {
            document.getElementById('resultSection').style.display = 'none';
            return;
        }

        const size = parseInt(document.getElementById('qrSize').value);
        const darkColor = document.getElementById('qrDarkColor').value;
        const lightColor = document.getElementById('qrLightColor').value;
        const level = document.getElementById('qrLevel').value;
        const container = document.getElementById('qrContainer');
        
        container.innerHTML = '';
        this.generatedCanvas = null;
        
        try {
            const levelMap = { L: 1, M: 0, Q: 3, H: 2 };
            
            new QRCode(container, {
                text: content,
                width: size,
                height: size,
                colorDark: darkColor,
                colorLight: lightColor,
                correctLevel: levelMap[level]
            });
            
            setTimeout(() => {
                const canvas = container.querySelector('canvas');
                if (canvas) {
                    this.generatedCanvas = canvas;
                }
                document.getElementById('resultSection').style.display = 'block';
            }, 100);
        } catch (e) {
            console.error('Exception:', e);
            Utils.showNotification('出错了', 'error');
        }
    }

    downloadPng() {
        const container = document.getElementById('qrContainer');
        const canvas = container.querySelector('canvas');
        
        if (!canvas) {
            Utils.showNotification('先生成二维码', 'error');
            return;
        }
        
        try {
            const dataUrl = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.href = dataUrl;
            link.download = 'qrcode.png';
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            Utils.showNotification('下载成功', 'success');
        } catch (e) {
            console.error('Download error:', e);
            Utils.showNotification('下载失败', 'error');
        }
    }
}

function initQRCode() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new QRCodeGenerator();
        });
    } else {
        new QRCodeGenerator();
    }
}

initQRCode();
