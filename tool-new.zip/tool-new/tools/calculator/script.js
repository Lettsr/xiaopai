class Calculator {
    constructor() {
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.shouldResetScreen = false;
        this.history = Utils.storage.get('calc_history', []);
        this.isScientific = false;
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.renderHistory();
    }

    bindEvents() {
        document.querySelectorAll('.calc-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.dataset.value !== undefined) {
                    this.appendNumber(btn.dataset.value);
                } else if (btn.dataset.action) {
                    this.handleAction(btn.dataset.action);
                }
            });
        });

        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.toggleMode(btn.dataset.mode);
            });
        });

        document.getElementById('clearHistory').addEventListener('click', () => {
            this.history = [];
            Utils.storage.set('calc_history', []);
            this.renderHistory();
        });

        document.addEventListener('keydown', (e) => {
            if (e.key >= '0' && e.key <= '9') {
                this.appendNumber(e.key);
            } else if (e.key === '.') {
                this.appendNumber('.');
            } else if (e.key === '+') {
                this.handleAction('add');
            } else if (e.key === '-') {
                this.handleAction('subtract');
            } else if (e.key === '*') {
                this.handleAction('multiply');
            } else if (e.key === '/') {
                this.handleAction('divide');
            } else if (e.key === 'Enter' || e.key === '=') {
                this.handleAction('equals');
            } else if (e.key === 'Escape') {
                this.handleAction('clear');
            } else if (e.key === 'Backspace') {
                this.handleAction('backspace');
            }
        });
    }

    toggleMode(mode) {
        this.isScientific = mode === 'scientific';
        document.querySelectorAll('.scientific-btns').forEach(row => {
            row.style.display = this.isScientific ? 'grid' : 'none';
        });
    }

    appendNumber(number) {
        if (this.shouldResetScreen) {
            this.currentValue = '';
            this.shouldResetScreen = false;
        }

        if (number === '.' && this.currentValue.includes('.')) return;
        
        if (this.currentValue === '0' && number !== '.') {
            this.currentValue = number;
        } else {
            this.currentValue += number;
        }

        this.updateDisplay();
    }

    handleAction(action) {
        switch (action) {
            case 'clear':
                this.clear();
                break;
            case 'backspace':
                this.backspace();
                break;
            case 'add':
            case 'subtract':
            case 'multiply':
            case 'divide':
                this.setOperation(action);
                break;
            case 'equals':
                this.calculate();
                break;
            case 'percent':
                this.percent();
                break;
            case 'negate':
                this.negate();
                break;
            case 'sin':
            case 'cos':
            case 'tan':
            case 'log':
            case 'ln':
            case 'sqrt':
            case 'pow':
            case 'cube':
                this.scientificOperation(action);
                break;
            case 'pi':
                this.currentValue = Math.PI.toString();
                this.shouldResetScreen = true;
                this.updateDisplay();
                break;
            case 'e':
                this.currentValue = Math.E.toString();
                this.shouldResetScreen = true;
                this.updateDisplay();
                break;
        }
    }

    clear() {
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.updateDisplay();
        document.getElementById('expression').textContent = '';
    }

    backspace() {
        if (this.currentValue.length === 1 || 
            (this.currentValue.length === 2 && this.currentValue.startsWith('-'))) {
            this.currentValue = '0';
        } else {
            this.currentValue = this.currentValue.slice(0, -1);
        }
        this.updateDisplay();
    }

    setOperation(op) {
        if (this.operation !== null) {
            this.calculate();
        }
        
        this.previousValue = this.currentValue;
        this.operation = op;
        this.shouldResetScreen = true;

        const symbols = { add: '+', subtract: '−', multiply: '×', divide: '÷' };
        document.getElementById('expression').textContent = 
            `${this.formatNumber(this.previousValue)} ${symbols[op]}`;
    }

    calculate() {
        if (this.operation === null || this.previousValue === '') return;

        const prev = parseFloat(this.previousValue);
        const current = parseFloat(this.currentValue);
        let result;

        switch (this.operation) {
            case 'add':
                result = prev + current;
                break;
            case 'subtract':
                result = prev - current;
                break;
            case 'multiply':
                result = prev * current;
                break;
            case 'divide':
                result = current === 0 ? 'Error' : prev / current;
                break;
        }

        const symbols = { add: '+', subtract: '−', multiply: '×', divide: '÷' };
        const expression = `${this.formatNumber(this.previousValue)} ${symbols[this.operation]} ${this.formatNumber(this.currentValue)}`;
        
        if (result !== 'Error') {
            this.addToHistory(expression, result);
        }

        this.currentValue = result === 'Error' ? 'Error' : this.formatResult(result);
        this.previousValue = '';
        this.operation = null;
        this.shouldResetScreen = true;
        this.updateDisplay();
        document.getElementById('expression').textContent = expression + ' =';
    }

    scientificOperation(action) {
        const value = parseFloat(this.currentValue);
        let result;
        let expr = '';

        switch (action) {
            case 'sin':
                result = Math.sin(value * Math.PI / 180);
                expr = `sin(${value}°)`;
                break;
            case 'cos':
                result = Math.cos(value * Math.PI / 180);
                expr = `cos(${value}°)`;
                break;
            case 'tan':
                result = Math.tan(value * Math.PI / 180);
                expr = `tan(${value}°)`;
                break;
            case 'log':
                result = Math.log10(value);
                expr = `log(${value})`;
                break;
            case 'ln':
                result = Math.log(value);
                expr = `ln(${value})`;
                break;
            case 'sqrt':
                result = Math.sqrt(value);
                expr = `√${value}`;
                break;
            case 'pow':
                result = Math.pow(value, 2);
                expr = `${value}²`;
                break;
            case 'cube':
                result = Math.pow(value, 3);
                expr = `${value}³`;
                break;
        }

        this.addToHistory(expr, result);
        this.currentValue = this.formatResult(result);
        this.shouldResetScreen = true;
        this.updateDisplay();
        document.getElementById('expression').textContent = expr + ' =';
    }

    percent() {
        this.currentValue = this.formatResult(parseFloat(this.currentValue) / 100);
        this.updateDisplay();
    }

    negate() {
        if (this.currentValue !== '0') {
            this.currentValue = this.currentValue.startsWith('-') 
                ? this.currentValue.slice(1) 
                : '-' + this.currentValue;
            this.updateDisplay();
        }
    }

    formatResult(num) {
        if (isNaN(num) || !isFinite(num)) return 'Error';
        const rounded = Math.round(num * 1e10) / 1e10;
        return rounded.toString();
    }

    formatNumber(num) {
        return parseFloat(num).toLocaleString('zh-CN', { maximumFractionDigits: 10 });
    }

    updateDisplay() {
        const resultEl = document.getElementById('result');
        let displayValue = this.currentValue;
        
        if (displayValue !== 'Error' && !displayValue.includes('e')) {
            const parts = displayValue.split('.');
            parts[0] = parseFloat(parts[0]).toLocaleString('zh-CN');
            displayValue = parts.join('.');
        }
        
        resultEl.textContent = displayValue;
        
        if (displayValue.length > 12) {
            resultEl.style.fontSize = '24px';
        } else {
            resultEl.style.fontSize = '36px';
        }
    }

    addToHistory(expression, result) {
        this.history.unshift({
            expression,
            result: this.formatResult(result)
        });
        
        if (this.history.length > 20) {
            this.history.pop();
        }
        
        Utils.storage.set('calc_history', this.history);
        this.renderHistory();
    }

    renderHistory() {
        const list = document.getElementById('historyList');
        
        if (this.history.length === 0) {
            list.innerHTML = '<div class="history-item"><span class="history-expr">暂无历史记录</span></div>';
            return;
        }

        list.innerHTML = this.history.map(item => `
            <div class="history-item" data-result="${item.result}">
                <div class="history-expr">${item.expression}</div>
                <div class="history-result">= ${this.formatNumber(item.result)}</div>
            </div>
        `).join('');

        list.querySelectorAll('.history-item').forEach(item => {
            item.addEventListener('click', () => {
                this.currentValue = item.dataset.result;
                this.updateDisplay();
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => new Calculator());
