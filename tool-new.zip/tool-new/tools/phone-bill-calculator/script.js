class PhoneBillCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const monthlyFee = parseFloat(document.getElementById('monthlyFee').value);
        const callMinutes = parseInt(document.getElementById('callMinutes').value);
        const includedMinutes = parseInt(document.getElementById('includedMinutes').value);
        const extraRate = parseFloat(document.getElementById('extraRate').value);

        if (!monthlyFee || !callMinutes || !includedMinutes || !extraRate) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        const extraMinutes = Math.max(0, callMinutes - includedMinutes);
        const extraCost = extraMinutes * extraRate;
        const totalCost = monthlyFee + extraCost;

        document.getElementById('monthlyFeeResult').textContent = `¥${monthlyFee.toFixed(2)}`;
        document.getElementById('extraCost').textContent = extraCost > 0 ? `¥${extraCost.toFixed(2)}` : '¥0.00';
        document.getElementById('totalCost').textContent = `¥${totalCost.toFixed(2)}`;

        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new PhoneBillCalculator());
