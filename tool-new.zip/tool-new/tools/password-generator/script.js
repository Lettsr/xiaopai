class PasswordGenerator {
    constructor() {
        this.uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        this.lowercase = 'abcdefghijklmnopqrstuvwxyz';
        this.numbers = '0123456789';
        this.symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
        this.history = Utils.storage.get('password_history', []);
        this.init();
    }

    init() {
        this.bindEvents();
        this.generate();
        this.renderHistory();
    }

    bindEvents() {
        document.getElementById('generateBtn').addEventListener('click', () => this.generate());
        document.getElementById('refreshBtn').addEventListener('click', () => this.generate());
        
        document.getElementById('copyBtn').addEventListener('click', () => this.copyPassword());

        document.getElementById('lengthSlider').addEventListener('input', (e) => {
            document.getElementById('lengthInput').value = e.target.value;
            this.generate();
        });

        document.getElementById('lengthInput').addEventListener('input', (e) => {
            let value = parseInt(e.target.value) || 4;
            value = Math.max(4, Math.min(64, value));
            document.getElementById('lengthSlider').value = value;
            this.generate();
        });

        ['uppercase', 'lowercase', 'numbers', 'symbols'].forEach(id => {
            document.getElementById(id).addEventListener('change', () => this.generate());
        });

        document.getElementById('excludeChars').addEventListener('input', () => this.generate());

        document.getElementById('batchBtn').addEventListener('click', () => this.batchGenerate());

        document.getElementById('clearHistory').addEventListener('click', () => {
            this.history = [];
            Utils.storage.set('password_history', []);
            this.renderHistory();
        });
    }

    getCharset() {
        let charset = '';
        const excludeChars = document.getElementById('excludeChars').value;

        if (document.getElementById('uppercase').checked) charset += this.uppercase;
        if (document.getElementById('lowercase').checked) charset += this.lowercase;
        if (document.getElementById('numbers').checked) charset += this.numbers;
        if (document.getElementById('symbols').checked) charset += this.symbols;

        if (excludeChars) {
            charset = charset.split('').filter(c => !excludeChars.includes(c)).join('');
        }

        return charset;
    }

    generate() {
        const charset = this.getCharset();
        if (!charset) {
            Utils.showNotification('请至少选择一种字符类型', 'warning');
            return;
        }

        const length = parseInt(document.getElementById('lengthInput').value) || 16;
        let password = '';

        const array = new Uint32Array(length);
        crypto.getRandomValues(array);

        for (let i = 0; i < length; i++) {
            password += charset[array[i] % charset.length];
        }

        document.getElementById('passwordOutput').value = password;
        this.updateStrength(password);
        this.addToHistory(password);
    }

    batchGenerate() {
        const count = parseInt(document.getElementById('batchCount').value);
        const passwords = [];

        for (let i = 0; i < count; i++) {
            this.generate();
            passwords.push(document.getElementById('passwordOutput').value);
        }

        const allPasswords = passwords.join('\n');
        Utils.copyToClipboard(allPasswords);
        Utils.showNotification(`已生成 ${count} 个密码并复制到剪贴板`, 'success');
    }

    updateStrength(password) {
        let score = 0;
        
        if (password.length >= 8) score++;
        if (password.length >= 12) score++;
        if (password.length >= 16) score++;
        if (/[a-z]/.test(password)) score++;
        if (/[A-Z]/.test(password)) score++;
        if (/[0-9]/.test(password)) score++;
        if (/[^a-zA-Z0-9]/.test(password)) score++;

        const bar = document.getElementById('strengthBar');
        const text = document.getElementById('strengthText');

        bar.className = 'strength-bar';
        text.className = 'strength-text';

        if (score <= 2) {
            bar.classList.add('weak');
            text.classList.add('weak');
            text.textContent = '弱 - 建议增加长度和字符类型';
        } else if (score <= 4) {
            bar.classList.add('fair');
            text.classList.add('fair');
            text.textContent = '一般 - 可以更强';
        } else if (score <= 6) {
            bar.classList.add('good');
            text.classList.add('good');
            text.textContent = '良好 - 较为安全';
        } else {
            bar.classList.add('strong');
            text.classList.add('strong');
            text.textContent = '强 - 非常安全';
        }
    }

    async copyPassword() {
        const password = document.getElementById('passwordOutput').value;
        const btn = document.getElementById('copyBtn');
        
        const success = await Utils.copyToClipboard(password);
        
        if (success) {
            btn.classList.add('copied');
            btn.querySelector('span').textContent = '✓';
            Utils.showNotification('密码已复制到剪贴板', 'success');
            
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.querySelector('span').textContent = '📋';
            }, 2000);
        }
    }

    addToHistory(password) {
        this.history.unshift({
            password,
            time: new Date().toLocaleTimeString('zh-CN')
        });

        if (this.history.length > 20) {
            this.history.pop();
        }

        Utils.storage.set('password_history', this.history);
        this.renderHistory();
    }

    renderHistory() {
        const section = document.getElementById('historySection');
        const list = document.getElementById('historyList');

        if (this.history.length === 0) {
            section.style.display = 'none';
            return;
        }

        section.style.display = 'block';
        list.innerHTML = this.history.slice(0, 10).map(item => `
            <div class="history-item">
                <span class="password">${item.password}</span>
                <button class="copy-item" data-password="${item.password}">复制</button>
            </div>
        `).join('');

        list.querySelectorAll('.copy-item').forEach(btn => {
            btn.addEventListener('click', async () => {
                await Utils.copyToClipboard(btn.dataset.password);
                Utils.showNotification('已复制', 'success');
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => new PasswordGenerator());
