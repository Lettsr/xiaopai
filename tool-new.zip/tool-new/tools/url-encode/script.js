class URLEncoder {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('encodeBtn').addEventListener('click', () => this.encode());
        document.getElementById('decodeBtn').addEventListener('click', () => this.decode());

        document.getElementById('copyEncode').addEventListener('click', () => {
            this.copyToClipboard('encodeOutput', 'copyEncode');
        });

        document.getElementById('copyDecode').addEventListener('click', () => {
            this.copyToClipboard('decodeOutput', 'copyDecode');
        });

        document.getElementById('parseBtn').addEventListener('click', () => this.parseURL());

        document.getElementById('encodeInput').addEventListener('input', 
            Utils.debounce(() => this.encode(), 300)
        );

        document.getElementById('decodeInput').addEventListener('input', 
            Utils.debounce(() => this.decode(), 300)
        );
    }

    encode() {
        const input = document.getElementById('encodeInput').value;
        if (!input) {
            document.getElementById('encodeOutput').value = '';
            return;
        }

        try {
            const encoded = encodeURIComponent(input);
            document.getElementById('encodeOutput').value = encoded;
        } catch (e) {
            Utils.showNotification('编码失败', 'error');
        }
    }

    decode() {
        const input = document.getElementById('decodeInput').value;
        if (!input) {
            document.getElementById('decodeOutput').value = '';
            return;
        }

        try {
            const decoded = decodeURIComponent(input);
            document.getElementById('decodeOutput').value = decoded;
        } catch (e) {
            document.getElementById('decodeOutput').value = '解码失败: 无效的URL编码';
            Utils.showNotification('解码失败: 无效的URL编码', 'error');
        }
    }

    parseURL() {
        const input = document.getElementById('urlParseInput').value.trim();
        if (!input) {
            Utils.showNotification('请输入URL', 'warning');
            return;
        }

        try {
            const url = new URL(input);

            document.getElementById('compProtocol').textContent = url.protocol.replace(':', '') || '-';
            document.getElementById('compHost').textContent = url.hostname || '-';
            document.getElementById('compPort').textContent = url.port || '(默认)';
            document.getElementById('compPath').textContent = url.pathname || '/';
            document.getElementById('compQuery').textContent = url.search || '(无)';
            document.getElementById('compHash').textContent = url.hash || '(无)';
        } catch (e) {
            Utils.showNotification('无效的URL格式', 'error');
            
            document.getElementById('compProtocol').textContent = '-';
            document.getElementById('compHost').textContent = '-';
            document.getElementById('compPort').textContent = '-';
            document.getElementById('compPath').textContent = '-';
            document.getElementById('compQuery').textContent = '-';
            document.getElementById('compHash').textContent = '-';
        }
    }

    async copyToClipboard(inputId, btnId) {
        const text = document.getElementById(inputId).value;
        if (!text) return;

        const btn = document.getElementById(btnId);
        const success = await Utils.copyToClipboard(text);

        if (success) {
            btn.textContent = '已复制';
            btn.classList.add('copied');
            Utils.showNotification('已复制到剪贴板', 'success');

            setTimeout(() => {
                btn.textContent = '复制';
                btn.classList.remove('copied');
            }, 2000);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => new URLEncoder());
