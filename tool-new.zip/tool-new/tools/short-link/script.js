class ShortLinkGenerator {
    constructor() {
        this.history = this.loadHistory();
        this.init();
    }

    init() {
        this.bindEvents();
        this.renderHistory();
    }

    bindEvents() {
        document.getElementById('generateBtn').addEventListener('click', () => this.generate());
        document.getElementById('copyBtn').addEventListener('click', () => this.copy());
        document.getElementById('originalUrl').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.generate();
        });
    }

    generate() {
        const originalUrl = document.getElementById('originalUrl').value.trim();
        
        if (!originalUrl) {
            Utils.showNotification('请输入链接', 'error');
            return;
        }

        const shortCode = this.generateShortCode();
        const shortUrl = `https://s.l/${shortCode}`;

        document.getElementById('shortUrl').value = shortUrl;
        document.getElementById('resultSection').style.display = 'block';

        this.addToHistory(originalUrl, shortUrl);
        Utils.showNotification('短链接生成成功', 'success');
    }

    generateShortCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let code = '';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }

    addToHistory(original, short) {
        const item = {
            original,
            short,
            time: new Date().toLocaleString('zh-CN')
        };
        this.history.unshift(item);
        if (this.history.length > 10) {
            this.history.pop();
        }
        this.saveHistory();
        this.renderHistory();
    }

    renderHistory() {
        const container = document.getElementById('historyList');
        if (this.history.length === 0) {
            container.innerHTML = '<div class="empty-history">暂无历史记录</div>';
            return;
        }

        container.innerHTML = this.history.map((item, index) => `
            <div class="history-item">
                <div class="history-original">${this.escapeHtml(item.original)}</div>
                <div class="history-short">${item.short}</div>
                <div class="history-time">${item.time}</div>
                <button class="use-btn" onclick="shortLinkGenerator.useHistory(${index})">使用</button>
            </div>
        `).join('');
    }

    useHistory(index) {
        document.getElementById('originalUrl').value = this.history[index].original;
        Utils.showNotification('已填入链接', 'info');
    }

    copy() {
        const shortUrl = document.getElementById('shortUrl').value;
        Utils.copyToClipboard(shortUrl);
        Utils.showNotification('已复制到剪贴板', 'success');
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    saveHistory() {
        localStorage.setItem('shortLinkHistory', JSON.stringify(this.history));
    }

    loadHistory() {
        const saved = localStorage.getItem('shortLinkHistory');
        return saved ? JSON.parse(saved) : [];
    }
}

let shortLinkGenerator;
document.addEventListener('DOMContentLoaded', () => {
    shortLinkGenerator = new ShortLinkGenerator();
});
