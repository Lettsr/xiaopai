class ElectricityCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());
    }

    calculate() {
        const electricity = parseFloat(document.getElementById('electricity').value);
        const pricePerKwh = parseFloat(document.getElementById('pricePerKwh').value);
        const tierType = document.getElementById('tierType').value;

        if (!electricity || !pricePerKwh) {
            Utils.showNotification('请填写完整信息', 'error');
            return;
        }

        let totalCost;
        if (tierType === 'standard') {
            totalCost = this.calculateTiered(electricity, pricePerKwh);
        } else {
            totalCost = electricity * pricePerKwh;
        }

        document.getElementById('totalCost').textContent = `¥${totalCost.toFixed(2)}`;
        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('计算成功', 'success');
    }

    calculateTiered(electricity, basePrice) {
        const tiers = [
            { limit: 240, rate: 1 },
            { limit: 400, rate: 1.1 },
            { limit: Infinity, rate: 1.3 }
        ];

        let total = 0;
        let remaining = electricity;

        for (const tier of tiers) {
            if (remaining <= 0) break;
            const usage = Math.min(remaining, tier.limit);
            total += usage * basePrice * tier.rate;
            remaining -= tier.limit;
        }

        return total;
    }
}

document.addEventListener('DOMContentLoaded', () => new ElectricityCalculator());
