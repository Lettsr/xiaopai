const currencies = {
    CNY: { name: '人民币', flag: '🇨🇳', rate: 1 },
    USD: { name: '美元', flag: '🇺🇸', rate: 0.1389 },
    EUR: { name: '欧元', flag: '🇪🇺', rate: 0.1278 },
    GBP: { name: '英镑', flag: '🇬🇧', rate: 0.1098 },
    JPY: { name: '日元', flag: '🇯🇵', rate: 20.89 },
    KRW: { name: '韩元', flag: '🇰🇷', rate: 185.42 },
    HKD: { name: '港币', flag: '🇭🇰', rate: 1.0856 },
    TWD: { name: '新台币', flag: '🇹🇼', rate: 4.4123 },
    SGD: { name: '新加坡元', flag: '🇸🇬', rate: 0.1867 },
    AUD: { name: '澳元', flag: '🇦🇺', rate: 0.2123 },
    CAD: { name: '加元', flag: '🇨🇦', rate: 0.1902 },
    CHF: { name: '瑞士法郎', flag: '🇨🇭', rate: 0.1234 },
    THB: { name: '泰铢', flag: '🇹🇭', rate: 4.8923 },
    MYR: { name: '马来西亚林吉特', flag: '🇲🇾', rate: 0.6543 },
    INR: { name: '印度卢比', flag: '🇮🇳', rate: 11.56 },
    RUB: { name: '俄罗斯卢布', flag: '🇷🇺', rate: 12.78 }
};

class CurrencyConverter {
    constructor() {
        this.fromCurrency = 'CNY';
        this.toCurrency = 'USD';
        this.init();
    }

    init() {
        this.populateSelects();
        this.bindEvents();
        this.convert();
        this.renderQuickConvert();
        this.renderPopularRates();
        this.updateTime();
    }

    populateSelects() {
        const fromSelect = document.getElementById('fromCurrency');
        const toSelect = document.getElementById('toCurrency');

        const options = Object.entries(currencies).map(([code, data]) => 
            `<option value="${code}">${data.flag} ${code}</option>`
        ).join('');

        fromSelect.innerHTML = options;
        toSelect.innerHTML = options;

        fromSelect.value = this.fromCurrency;
        toSelect.value = this.toCurrency;
    }

    bindEvents() {
        document.getElementById('fromAmount').addEventListener('input', () => this.convert());
        
        document.getElementById('fromCurrency').addEventListener('change', (e) => {
            this.fromCurrency = e.target.value;
            this.convert();
        });

        document.getElementById('toCurrency').addEventListener('change', (e) => {
            this.toCurrency = e.target.value;
            this.convert();
        });

        document.getElementById('swapBtn').addEventListener('click', () => this.swap());
    }

    convert() {
        const amount = parseFloat(document.getElementById('fromAmount').value) || 0;
        const fromRate = currencies[this.fromCurrency].rate;
        const toRate = currencies[this.toCurrency].rate;

        const cnyAmount = amount / fromRate;
        const result = cnyAmount * toRate;

        document.getElementById('toAmount').value = result.toFixed(4);

        const rate = toRate / fromRate;
        document.getElementById('rateDisplay').textContent = 
            `1 ${this.fromCurrency} = ${rate.toFixed(4)} ${this.toCurrency}`;
    }

    swap() {
        const temp = this.fromCurrency;
        this.fromCurrency = this.toCurrency;
        this.toCurrency = temp;

        document.getElementById('fromCurrency').value = this.fromCurrency;
        document.getElementById('toCurrency').value = this.toCurrency;

        const fromAmount = document.getElementById('fromAmount').value;
        const toAmount = document.getElementById('toAmount').value;
        document.getElementById('fromAmount').value = toAmount;

        this.convert();
    }

    renderQuickConvert() {
        const amounts = [1, 10, 100, 1000];
        const grid = document.getElementById('quickGrid');

        grid.innerHTML = amounts.map(amount => `
            <div class="quick-item" data-amount="${amount}">
                <div class="amount">${amount}</div>
            </div>
        `).join('');

        grid.querySelectorAll('.quick-item').forEach(item => {
            item.addEventListener('click', () => {
                document.getElementById('fromAmount').value = item.dataset.amount;
                this.convert();
            });
        });
    }

    renderPopularRates() {
        const popular = ['USD', 'EUR', 'GBP', 'JPY', 'HKD', 'KRW'];
        const grid = document.getElementById('ratesGrid');

        grid.innerHTML = popular.map(code => {
            const currency = currencies[code];
            return `
                <div class="rate-item">
                    <div class="currency-name">
                        <span class="currency-flag">${currency.flag}</span>
                        <span class="currency-code">${code}</span>
                    </div>
                    <span class="rate">${(currency.rate).toFixed(4)}</span>
                </div>
            `;
        }).join('');
    }

    updateTime() {
        const now = new Date();
        document.getElementById('updateTime').textContent = 
            `更新于 ${now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}`;
    }
}

document.addEventListener('DOMContentLoaded', () => new CurrencyConverter());
