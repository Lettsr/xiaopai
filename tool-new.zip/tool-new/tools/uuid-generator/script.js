class UUIDGenerator {
    constructor() {
        this.uuids = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.generate();
    }

    bindEvents() {
        document.getElementById('generateBtn').addEventListener('click', () => this.generate());
        document.getElementById('copyAllBtn').addEventListener('click', () => this.copyAll());
    }

    generate() {
        const count = parseInt(document.getElementById('uuidCount').value);
        const format = document.getElementById('uuidFormat').value;

        this.uuids = [];
        for (let i = 0; i < count; i++) {
            let uuid = this.generateUUID();
            
            if (format === 'uppercase') {
                uuid = uuid.toUpperCase();
            } else if (format === 'nohyphen') {
                uuid = uuid.replace(/-/g, '');
            }

            this.uuids.push(uuid);
        }

        this.render();
        Utils.showNotification(`已生成 ${count} 个 UUID', 'success');
    }

    generateUUID() {
        if (crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    render() {
        const container = document.getElementById('uuidList');
        container.innerHTML = this.uuids.map((uuid, index) => `
            <div class="uuid-item">
                <span class="uuid-index">${index + 1}</span>
                <span class="uuid-text">${uuid}</span>
                <button class="copy-btn" onclick="uuidGenerator.copyOne(${index})">复制</button>
            </div>
        `).join('');
    }

    copyOne(index) {
        Utils.copyToClipboard(this.uuids[index]);
        Utils.showNotification('已复制到剪贴板', 'success');
    }

    copyAll() {
        const all = this.uuids.join('\n');
        Utils.copyToClipboard(all);
        Utils.showNotification('已全部复制', 'success');
    }
}

let uuidGenerator;
document.addEventListener('DOMContentLoaded', () => {
    uuidGenerator = new UUIDGenerator();
});
