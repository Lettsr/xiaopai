class BMICalculator {
    constructor() {
        this.unit = 'metric';
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.querySelectorAll('.unit-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.unit-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.unit = btn.dataset.unit;
                this.updateLabels();
            });
        });

        document.getElementById('calculateBtn').addEventListener('click', () => this.calculate());

        document.getElementById('heightInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.calculate();
        });

        document.getElementById('weightInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.calculate();
        });
    }

    updateLabels() {
        const heightLabel = document.getElementById('heightLabel');
        const weightLabel = document.getElementById('weightLabel');

        if (this.unit === 'metric') {
            heightLabel.textContent = '身高 (厘米)';
            weightLabel.textContent = '体重 (千克)';
        } else {
            heightLabel.textContent = '身高 (英尺/英寸)';
            weightLabel.textContent = '体重 (磅)';
        }

        document.getElementById('heightInput').value = '';
        document.getElementById('weightInput').value = '';
        document.getElementById('resultSection').style.display = 'none';
    }

    calculate() {
        let height = parseFloat(document.getElementById('heightInput').value);
        let weight = parseFloat(document.getElementById('weightInput').value);

        if (!height || !weight) {
            Utils.showNotification('请输入身高和体重', 'warning');
            return;
        }

        if (this.unit === 'imperial') {
            weight = weight * 0.453592;
            height = height * 2.54;
        } else {
            height = height;
        }

        const heightM = height / 100;
        const bmi = weight / (heightM * heightM);

        this.displayResult(bmi, weight, height);
    }

    displayResult(bmi, weight, height) {
        document.getElementById('resultSection').style.display = 'block';
        document.getElementById('bmiValue').textContent = bmi.toFixed(1);

        const indicator = document.getElementById('scaleIndicator');
        let position = Math.min(100, Math.max(0, (bmi - 15) / 25 * 100));
        indicator.style.left = position + '%';

        const statusCard = document.getElementById('statusCard');
        const statusTitle = document.getElementById('statusTitle');
        const statusDesc = document.getElementById('statusDesc');

        let status, desc, color;

        if (bmi < 18.5) {
            status = '偏瘦';
            desc = '您的体重偏低，建议适当增加营养摄入，保持健康饮食。';
            color = '#3b82f6';
        } else if (bmi < 25) {
            status = '正常';
            desc = '恭喜！您的BMI在健康范围内，请继续保持良好的生活习惯。';
            color = '#22c55e';
        } else if (bmi < 30) {
            status = '超重';
            desc = '您的体重略微超标，建议适当控制饮食并增加运动量。';
            color = '#f59e0b';
        } else {
            status = '肥胖';
            desc = '您的体重超标较多，建议咨询医生制定健康的减重计划。';
            color = '#ef4444';
        }

        statusTitle.textContent = status;
        statusTitle.style.color = color;
        statusDesc.textContent = desc;

        const minHealthy = 18.5 * (height / 100) * (height / 100);
        const maxHealthy = 24.9 * (height / 100) * (height / 100);

        let healthyRangeText = `${minHealthy.toFixed(1)} - ${maxHealthy.toFixed(1)} kg`;
        if (this.unit === 'imperial') {
            healthyRangeText = `${(minHealthy * 2.205).toFixed(1)} - ${(maxHealthy * 2.205).toFixed(1)} lb`;
        }
        document.getElementById('healthyRange').textContent = healthyRangeText;

        let diff;
        if (weight < minHealthy) {
            diff = minHealthy - weight;
            document.getElementById('weightDiff').textContent = `需增重 ${diff.toFixed(1)} kg`;
        } else if (weight > maxHealthy) {
            diff = weight - maxHealthy;
            document.getElementById('weightDiff').textContent = `需减重 ${diff.toFixed(1)} kg`;
        } else {
            document.getElementById('weightDiff').textContent = '体重达标 ✓';
        }
    }
}

document.addEventListener('DOMContentLoaded', () => new BMICalculator());
