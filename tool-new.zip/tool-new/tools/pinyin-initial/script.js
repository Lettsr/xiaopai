class PinyinInitial {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.getElementById('extractBtn').addEventListener('click', () => this.extract());
        document.getElementById('copyBtn').addEventListener('click', () => this.copy());
        document.getElementById('inputText').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') this.extract();
        });
    }

    extract() {
        const text = document.getElementById('inputText').value;
        
        if (!text) {
            Utils.showNotification('请输入文本', 'error');
            return;
        }

        const mode = document.querySelector('input[name="outputMode"]:checked').value;
        const keepOther = document.getElementById('keepOther').checked;

        const result = PinyinData.extract(text, { mode, keepOther });

        document.getElementById('outputText').value = result;
        document.getElementById('resultSection').style.display = 'block';
        Utils.showNotification('提取成功', 'success');
    }

    copy() {
        const text = document.getElementById('outputText').value;
        Utils.copyToClipboard(text);
        Utils.showNotification('已复制到剪贴板', 'success');
    }
}

document.addEventListener('DOMContentLoaded', () => new PinyinInitial());
